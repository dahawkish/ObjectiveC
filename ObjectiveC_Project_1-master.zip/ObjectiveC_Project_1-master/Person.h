//
//  Person.h
//  revision4
//
//  Created by Golden Data on 2/7/15.
//  Copyright (c) 2015 Golden Data. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Person : NSObject
{
    int age;
    int weight;
}

@property int age, weight;

//- (void) print;
//- (void) setWeight:(int)w;
//- (void) setAge:(int)a;
//- (int) getValues;

@end


