//
//  Person.m
//  revision4
//
//  Created by Golden Data on 2/7/15.
//  Copyright (c) 2015 Golden Data. All rights reserved.
//

#import "Person.h"



@implementation Person

@synthesize age, weight;

//
//
//- (void) setAge:(int)a
//{
//    age=a;
//}
//
//- (void) setWeight:(int)w
//
//{
//    weight=w;
//}
//
//- (int) getValues
//{
//    return age;
//    
//}
//
//- (void) print
//{
//    NSLog(@"%i %i",age,weight);
//}

@end
