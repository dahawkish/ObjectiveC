//
//  Numz.m
//  Polymorphism
//
//  Created by Golden Data on 2/8/15.
//  Copyright (c) 2015 Golden Data. All rights reserved.
//

#import "Numz.h"

@implementation Numz

- (void) setNo: (int)a
{
    
    num1=a;
}
- (void) setNo2:(int)b{
    num3=b;
}

- (void) setNo3: (int)c{
    num3=c;
}

- (void) add
{
    NSLog(@"%i %i %i", num1, num2,num3);
}

- (void) print
{
    NSLog(@"I am here");
}



@end
