//
//  Charz.m
//  Polymorphism
//
//  Created by Golden Data on 2/8/15.
//  Copyright (c) 2015 Golden Data. All rights reserved.
//

#import "Charz.h"

@implementation Charz

- (void) setCha: (char)d
{
    
    char1=d;
}
- (void) setCha2:(char)e{
    char2=e;
}

- (void) setCha3: (char)f{
    
    char3=f;
    
}

- (void) add
{
    NSLog(@"%i %i %i", char1, char2, char3);
}

- (void) print
{
    NSLog(@"I am here");
}



@end
