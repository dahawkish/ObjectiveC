//
//  Numz.h
//  Polymorphism
//
//  Created by Golden Data on 2/8/15.
//  Copyright (c) 2015 Golden Data. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Numz : NSObject
{
    int num1;
    int num2;
    int num3;
}

- (void) setNo: (int)a;
- (void) setNo2:(int)b;
- (void) setNo3: (int)c;
- (void) add;
- (void) print;

@end
