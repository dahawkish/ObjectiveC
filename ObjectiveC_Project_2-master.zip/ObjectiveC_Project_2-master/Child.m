//
//  Child.m
//  revision6
//
//  Created by Golden Data on 2/8/15.
//  Copyright (c) 2015 Golden Data. All rights reserved.
//

#import "Child.h"
#import "Parent.h"

@implementation Child

- (void) printAge
{
    //use nslog and print value of age
    NSLog(@"Mom's age is %i",age);
}


@end
