//
//  Child.h
//  revision6
//
//  Created by Golden Data on 2/8/15.
//  Copyright (c) 2015 Golden Data. All rights reserved.
//

#import "Parent.h"

@interface Child : Parent
{
    int newage;
}

- (void) printAge;

@end
